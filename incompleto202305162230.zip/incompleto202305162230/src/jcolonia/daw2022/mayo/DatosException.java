package jcolonia.daw2022.mayo;

public class DatosException extends Exception {

	public DatosException() {
		// TODO Esbozo de constructor generado automáticamente
	}

	public DatosException(String message) {
		super(message);
		// TODO Esbozo de constructor generado automáticamente
	}

	public DatosException(Throwable cause) {
		super(cause);
		// TODO Esbozo de constructor generado automáticamente
	}

	public DatosException(String message, Throwable cause) {
		super(message, cause);
		// TODO Esbozo de constructor generado automáticamente
	}

	public DatosException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Esbozo de constructor generado automáticamente
	}

}
