package jcolonia.daw2022.mayo;

public class VistaException extends Exception {

	public VistaException() {
		// TODO Esbozo de constructor generado automáticamente
	}

	public VistaException(String message) {
		super(message);
		// TODO Esbozo de constructor generado automáticamente
	}

	public VistaException(Throwable cause) {
		super(cause);
		// TODO Esbozo de constructor generado automáticamente
	}

	public VistaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Esbozo de constructor generado automáticamente
	}

	public VistaException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Esbozo de constructor generado automáticamente
	}

}
