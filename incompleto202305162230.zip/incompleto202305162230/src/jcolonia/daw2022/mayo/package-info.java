/**
 * Aplicación de gestión de datos sobre consola de texto y estructura M-V-C:
 * Agenda. Ejercicio de evaluación sobre la UT6, primera prueba específica
 * parcial de la E3.
 * 
 * @author <a href="dmartin.jcolonia@gmail.com">David H. Martín</a>
 * @version 1.0 (20230504)
 */
package jcolonia.daw2022.mayo;
